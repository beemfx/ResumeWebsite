/******************************************************************************
File: EGCommon.h
Purpose: Header file that is included in every single game file. So this stuff
is always available without explicitly included in everything.

CL Compiler option /FI"EGCommon.h"
******************************************************************************/
#pragma once

//Enable some warnings:
#pragma warning(3:4100 4062 4505)

//#define EGUNICODE

#if defined(EGUNICODE)
#define UNICODE
#define _UNICODE
#endif

/****************
*** Assertion ***
****************/
#if defined(DEBUG)

//We have to use a macro so that the break actually goes to the line of code
//where the break occurred and not this file.
#if defined(__WIN32__) || defined( __WIN64__ )
#define assert(b) { if(!(b)){ __debugbreak(); } }
#else
#error No assert set for this platform.
#endif

#else

#define assert(b)

#endif

#define countof(b) (sizeof(b)/sizeof(b[0]))

template<class T> static void unused(T&){ }
template<class T, class U> static void unused(T&, U&){ }
template<class T, class U, class V> static void unused(T&, U&, V&){ }

//Numerical types:

typedef float            eg_real, eg_real32;
typedef double           eg_real64;
typedef signed long      eg_int, eg_int32;
typedef unsigned long    eg_uint, eg_uint32;
typedef unsigned short   eg_uint16;
typedef signed short     eg_int16;
typedef signed __int64   eg_int64;
typedef unsigned __int64 eg_uint64;
typedef unsigned char    eg_byte, eg_uint8;
typedef signed char      eg_int8;
typedef bool             eg_bool;
#if defined( __WIN32__ )
typedef unsigned int   eg_size_t;
#elif defined( __WIN64__ )
typedef unsigned __int64 eg_size_t;
#else
typedef unsigned int   eg_size_t;
#endif

#if defined( __WIN32__ )
typedef eg_int32 eg_intptr_t;
typedef eg_uint32 eg_uintptr_t;
#elif defined( __WIN64__ )
typedef eg_int64 eg_intptr_t;
typedef eg_uint64 eg_uintptr_t;
#else
typedef eg_int32 eg_intptr_t;
typedef eg_uint32 eg_uintptr_t;
#endif



//Character and string types:
typedef char             eg_char;
typedef char             eg_char8;
typedef wchar_t          eg_char16;
typedef eg_char*         eg_pstr;
typedef const eg_char*   eg_cpstr;
typedef eg_char8*        eg_pstr8;
typedef const eg_char8*  eg_cpstr8;
typedef eg_char16*       eg_pstr16;
typedef const eg_char16* eg_cpstr16;

static const eg_uint EG_MAX_PATH = 64;
typedef eg_char eg_path[EG_MAX_PATH];

typedef eg_uint8 eg_loc_char;

/***********************
*** Game Definitions ***
***********************/

static const eg_real EG_PI = 3.141592654f;
static const eg_real EG_1BYPI = 0.318309886f;

static const eg_uint EG_ALIGNMENT = 16;

#define EG_ALIGN __declspec(align(16))
#define EG_INLINE inline

//The print function type.
typedef void(*EG_FN_PRINT)(eg_cpstr strFormat, ...);

/******************
*** Game Macros ***
******************/

#ifdef __cplusplus
#define null (0)
#else /* __cplusplus */
#define null ((void*)0)
#endif __cplusplus

#include "EGString.h"

#define EGMem_Copy memcpy

//EG_printf is the primary debugging function. It can be specified according
//to platform, but it is meant to print information to the console. In WIN32
//it also prints to the debugger output box in Visual Studio.
//Each tool must have it's own implementation of EG_printf.
void EG_printf(eg_cpstr strFormat, ...);
