// EGParseDemo.cpp : Defines the entry point for the console application.
//
#include "EGCommon.h"
#include "Parse.h"

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>

static struct MainData
{
	eg_bool ShouldQuit;

	MainData(): ShouldQuit(false){}
} Main_Data;

static void Main_HandleAdd(const egParseFuncInfo& Info)
{
	if (Info.NumParms != 2)
	{
		printf("add must be in the form \"add( number , number )\"\n");
		return;
	}

	eg_real n1 = Info.Parms[0].ToFloat();
	eg_real n2 = Info.Parms[1].ToFloat();

	eg_real res = n1 + n2;
	printf("add( %g , %g ) = %g", n1, n2, res);
}

static void Main_ShowResults( EGPARSE_RESULT Res , const egParseFuncInfo& Info )
{
	if( EGPARSE_OKAY != Res )
	{
		printf( "Failed to parse function with error: %s.\n" , EGParse_GetParseResultString( Res ) );
		return;
	}
	printf( "Function Module: %s\n" , Info.SystemName.Length() > 0 ? Info.SystemName.String() : "N/A" );
	printf( "Function Name: %s\n", Info.FunctionName.String() );
	printf( "%u Parms:\n", Info.NumParms );
	for( eg_uint i=0; i<Info.NumParms; i++ )
	{
		printf( "   Parm %u: %s\n", i, Info.Parms[i].String() );
	}

	if( "Math" == Info.SystemName && "add" == Info.FunctionName )
	{
		Main_HandleAdd( Info );
	}
	else if( "quit" == Info.FunctionName )
	{
		Main_Data.ShouldQuit = true;
	}
}

static void Main_TestString( eg_cpstr Str )
{
	printf( "\n-----\n");
	printf( "Parsing: %s\n\n", Str );
	egParseFuncInfo Info;
	EGPARSE_RESULT Result = EGParse_ParseFunction( Str , &Info );
	Main_ShowResults (Result , Info );
}

static void Main_Cls()
{
	system( "cls" );
}

int main(int argc, char* argv[])
{
	unused( argc , argv );

	Main_TestString( "system.Print(\"Hello my nickname is \\\"Jack\\\"\", Jack , 1f )" );
	Main_TestString( "Print( \"Hi my nickname is \"Jack\"\")" ); //Error " is not escaped with backslash
	Main_TestString( "TwoNumbers( 1 2 )" );
	Main_TestString( "Math.add( 1.2 , -2.87 )" );
	Main_TestString( "sys1.sys2.DoThis()");

	while( !Main_Data.ShouldQuit )
	{
		printf( "\n\nType in a function expression to see the results \"quit()\" to exit:\n" );
		eg_char Str[1024];
		gets_s(Str);
		Main_Cls();
		Main_TestString( Str );
	}

	printf( "Press any key to continue.\n");
	_getch();
	return 0;
}

