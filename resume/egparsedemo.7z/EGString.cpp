#include "EGCommon.h"
#include "EGString.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

eg_string EGString_Format( eg_cpstr strFormat , ... )
{
	eg_string sTemp;
	va_list arglist = null;
	va_start(arglist,strFormat);
	eg_char Temp[1024];
	_vsnprintf_s(Temp, countof(Temp), _TRUNCATE, strFormat, arglist);
	Temp[countof(Temp)-1] = 0;
	va_end(arglist);
	sTemp = Temp;
	return sTemp;
}

eg_bool eg_string::Contains(eg_cpstr strSubStr)const
{
	return (NULL != strstr(m_strString, strSubStr));
}


void eg_string::UpdateLength()
{
	m_nLength=static_cast<eg_uint>(strlen(m_strString));
}

eg_string::eg_string()
{
	m_strString[0]=0;
	UpdateLength();
}

eg_string::eg_string(eg_cpstr8 str)
{
	*this = str;
}

eg_string::eg_string(eg_cpstr16 str)
{
	*this = str;
}

eg_string::eg_string(const eg_string& str)
{
	strncpy_s(m_strString, STR_SIZE, str.String(), _TRUNCATE);
	m_nLength=str.m_nLength;
}


eg_string::~eg_string()
{

}

void eg_string::Clear()
{
	m_strString[0]=0;
	m_strString[STR_SIZE-1]=0;
	m_nLength=0;
}

void eg_string::Append(eg_cpstr str)
{
	if(str)
	{
		strcat_s(m_strString,STR_SIZE, str);
		UpdateLength();
	}
}

void eg_string::Append(const eg_string& str)
{
	strcat_s(m_strString, STR_SIZE, str.String());
	m_strString[STR_SIZE-1] = 0;
	UpdateLength();
}

void eg_string::Append(const eg_char c)
{
	if(m_nLength==(STR_SIZE-1))
		return;
		
	m_strString[m_nLength]=c;
	m_nLength++;
	m_strString[m_nLength]=0;
}

const eg_string& eg_string::operator += (const eg_char c)
{
	Append(c);
	return *this;
}

void eg_string::AppendSpaces(const eg_uint count)
{
	for(eg_uint i=0; i<count; i++)
		Append(' ');
}

void eg_string::ClampEnd(eg_uint nCount)
{
	nCount=((nCount)<(m_nLength))?(nCount):(m_nLength);//EG_Min(nCount, m_nLength);
	m_strString[m_nLength-nCount]=0;
	m_nLength=m_nLength-nCount;
}


void eg_string::ConvertToUpper()
{
	_strupr_s(m_strString, STR_SIZE);
}

void eg_string::ConvertToLower()
{
	_strlwr_s(m_strString, STR_SIZE );
}

eg_int eg_string::Compare(eg_cpstr s1, eg_cpstr s2)
{
	return strcmp(s1, s2);
}

eg_int eg_string::CompareI(eg_cpstr s1, eg_cpstr s2)
{
	return _stricmp(s1, s2);
}

eg_bool eg_string::EqualsCount(eg_cpstr s1, eg_cpstr s2, eg_uint Count)
{
	return !strncmp(s1, s2, Count);
}

eg_bool eg_string::EqualsCountI(eg_cpstr s1, eg_cpstr s2, eg_uint Count)
{
	return !_strnicmp(s1, s2, Count);
}

eg_int eg_string::Compare(const eg_string& rhs)const
{
	return strcmp(m_strString, rhs.m_strString);
}
eg_int eg_string::Compare(eg_cpstr rhs)const
{
	return strcmp(m_strString, rhs);
}

eg_int eg_string::CompareI(const eg_string& rhs)const
{
	return _stricmp(m_strString, rhs.m_strString);
}

eg_int eg_string::CompareI(eg_cpstr rhs)const
{
	return _stricmp(m_strString, rhs);
}

const eg_string& eg_string::operator = (const eg_string& rhs)
{
	Clear();
	Append(rhs);
	return *this;
}
const eg_string& eg_string::operator = (eg_cpstr8 rhs)
{
	Clear();
	Copy( this->m_strString, rhs, this->STR_SIZE );
	this->UpdateLength();
	return *this;
}

const eg_string& eg_string::operator = (eg_cpstr16 rhs)
{
	Clear();
	Copy( this->m_strString, rhs, this->STR_SIZE );
	this->UpdateLength();
	return *this;
}
	
const eg_string& eg_string::operator += (const eg_string& rhs)
{
	Append(rhs);
	return *this;
}

const eg_string& eg_string::operator += (eg_cpstr rhs)
{
	Append(rhs);
	return *this;
}

const eg_string eg_string::operator + (const eg_string& rhs)
{
	eg_string Out = *this;
	Out += rhs;
	return Out;
}

const eg_string& eg_string::operator -- ()
{
	this->ClampEnd(1);
	return *this;
}
const eg_string& eg_string::operator -= (const eg_uint rhs)
{
	this->ClampEnd(rhs);
	return *this;
}

eg_char& eg_string::operator[](const eg_size_t rhs)
{
	return m_strString[rhs];
}

eg_string::operator eg_cpstr()const
{
	return String();
}

eg_string::operator const void*()const
{
	return String();
}

eg_string::operator const eg_string&()const
{
	return *this;
}
	
eg_cpstr eg_string::String()const
{
	return m_strString;
}

eg_uint eg_string::Length()const
{
	return m_nLength;
}

eg_bool eg_string::IsNumber()const
{
	const eg_char OkayList[] = ("0123456789.");
	eg_uint nPos = 0;
	if(0 == Length())return false;
	
	if(m_strString[nPos] == '-' && Length() >=2)
	{
		nPos++;
	}

	for( ; nPos<Length(); nPos++)
	{
		eg_bool bOkay = false;
		for(eg_uint i=0; i<countof(OkayList); i++)
		{
			if(OkayList[i] == m_strString[nPos])
			{
				bOkay = true;
				break;
			}
		}

		if(!bOkay)return false;
	}

	return true;
}

eg_real eg_string::ToFloat()const
{
	return (eg_real)atof(m_strString);
}
eg_uint eg_string::ToUInt()const
{
	return atol(m_strString);
}
eg_uint eg_string::ToUIntArray(eg_uint* anOut, const eg_uint nMaxNums)const
{
	//For text, it is necessary to tokenize:
	eg_char strDel[]=(" \n\r\t,;");
				
	eg_char strTemp[STR_SIZE*2];
	EGMem_Copy(strTemp, m_strString, (m_nLength+1)*sizeof(eg_char));
	//Just tokenize the string, and insert into the list
	eg_string strToken;
	eg_char* ct;
	eg_char* tok = strtok_s(strTemp, strDel, &ct);
	eg_uint* pDest = anOut;
	eg_uint nPos=0;
	while(tok && nPos<nMaxNums)
	{
		strToken=tok;
		pDest[nPos++]=strToken.ToUInt();
		tok=strtok_s(null, strDel, &ct);
	}

	return nPos;
}
eg_uint  eg_string::ToRealArray(eg_real* Out , eg_uint MaxOut )
{
	eg_char strTemp[STR_SIZE*2];
	//For text, it is necessary to tokenize:
	eg_char strDel[]=(" \n\r\t,;");
			
	EGMem_Copy(strTemp, m_strString, (m_nLength+1)*sizeof(eg_char));
	//Just tokenize the string, and insert into the list
	eg_string strToken;
	eg_char* ct;
	eg_char* tok = strtok_s(strTemp, strDel, &ct);
	eg_real* pDest = Out;
	eg_uint nPos=0;
	while(tok && nPos<MaxOut)
	{
		strToken=tok;
		pDest[nPos++]=strToken.ToFloat();
		tok=strtok_s(null, strDel, &ct);
	}

	return nPos;
}
eg_int  eg_string::ToInt()const
{
	return atol(m_strString);
}
eg_uint eg_string::ToUIntFromHex()const
{
	eg_char  c=0;
	eg_uint nHexValue=0;
	eg_uint SkipChars = 2;
	
	eg_cpstr in = m_strString;
	
	if(in[0]!='0' || (in[1]!='x' && in[1]!='X'))
		SkipChars=0;
		

	/* The idea behind this is keep adding to value, until
		we reach an invalid character, or the end of the string. */
	for(eg_uint i=SkipChars; in[i]!=0; i++)
	{
		c=in[i];
		
		if(c>='0' && c<='9')
			nHexValue=(nHexValue<<4)|(c-'0');
		else if(c>='a' && c<='f')
			nHexValue=(nHexValue<<4)|(c-'a'+10);
		else if(c>='A' && c<='F')
			nHexValue=(nHexValue<<4)|(c-'A'+10);
		else
			break;
	}
	
	return nHexValue;
}

void eg_string::CopyTo(eg_char8* strOut, eg_size_t size_out)const
{
	const eg_uint MAX = 1 == sizeof(eg_char) ? 256 : 65536;

	if(0 == size_out)return;

	for(eg_uint i=0; i<size_out; i++)
	{
		eg_char c = m_strString[i];
		if( c>= MAX)
		{
			c = UNICODE_DOWNCAST_CHAR;
		}
		strOut[i]=static_cast<eg_char8>(c);
		if(strOut[i]==0)
			break;
	}
	strOut[size_out-1]=0;
}

void eg_string::CopyTo(eg_char16* strOut, eg_size_t size_out)const
{
	if(0 == size_out)return;

	for(eg_uint i=0; i<size_out; i++)
	{
		strOut[i]=m_strString[i];
		if(strOut[i]==0)
			break;
	}
	strOut[size_out-1]=0;
}

void eg_string::Copy(eg_char* Dest, const eg_char8* Src, eg_uint size_out)
{
	if(0 == size_out)return;

	for(eg_uint i=0; i<size_out; i++)
	{
		Dest[i]=Src[i];
		if(Dest[i]==0)
			break;
	}
	Dest[size_out-1]=0;
}


void eg_string::Copy(eg_char* Dest, const eg_char16* Src, eg_uint size_out)
{
	const eg_uint MAX = 1 == sizeof(eg_char) ? 256 : 65536;
	if(null == Dest || null == Src)return;

	for(eg_uint i=0; i<size_out; i++, Src++)
	{
		eg_char16 c = *Src;
		if( c>= MAX )
		{
			c = UNICODE_DOWNCAST_CHAR;
		}
		Dest[i] = static_cast<eg_char>(c);

		if( '\0' == Dest[i])
			break;
	}
	Dest[size_out-1] = '\0';
	return;
}