#pragma once

class eg_string
{
public:
	eg_string();
	eg_string(eg_cpstr8 str);
	eg_string(eg_cpstr16 str);
	eg_string(const eg_string& str);

	~eg_string();

	void Clear();

	void Append(eg_cpstr str);
	void Append(const eg_string& str);
	void Append(const eg_char c);
	void AppendSpaces(const eg_uint count);

	void ClampEnd(eg_uint nCount);
	void ConvertToUpper();
	void ConvertToLower();

	static eg_int Compare(eg_cpstr s1, eg_cpstr s2);
	static eg_int CompareI(eg_cpstr s1, eg_cpstr s2);
	static eg_bool Equals(eg_cpstr s1, eg_cpstr s2)  { return !Compare(s1, s2); };
	static eg_bool EqualsI(eg_cpstr s1, eg_cpstr s2) { return !CompareI(s1, s2); };
	static eg_bool EqualsCount(eg_cpstr s1, eg_cpstr s2, eg_uint Count);
	static eg_bool EqualsCountI(eg_cpstr s1, eg_cpstr s2, eg_uint Count);
	eg_int Compare(const eg_string& rhs)const;
	eg_int Compare(eg_cpstr rhs)const;
	eg_int CompareI(const eg_string& rhs)const;
	eg_int CompareI(eg_cpstr rhs)const;
	eg_bool Equals(const eg_string& rhs)const { return !Compare(rhs); }
	eg_bool Equals(const eg_cpstr rhs)const  { return !Compare(rhs); }
	eg_bool EqualsI(const eg_string& rhs)const{ return !CompareI(rhs); }
	eg_bool EqualsI(const eg_cpstr rhs)const { return !CompareI(rhs); }


	eg_bool Contains(eg_cpstr strSubStr)const;

	const eg_string& operator = (const eg_string& rhs);
	const eg_string& operator = (eg_cpstr8 rhs);
	const eg_string& operator = (eg_cpstr16 rhs);

	const eg_string& operator += (const eg_string& rhs);
	const eg_string& operator += (eg_cpstr rhs);
	const eg_string& operator += (const eg_char c);

	const eg_string operator + (const eg_string& rhs2);

	const eg_string& operator -- ();
	const eg_string& operator -= (const eg_uint rhs);

	eg_bool operator==(eg_cpstr16 rhs)const{ return Equals(rhs); }
	eg_bool operator==(eg_cpstr8 rhs)const{ return Equals(rhs); }
	eg_bool operator==(const eg_string& rhs)const{ return Equals(rhs); }
	eg_bool operator!=(eg_cpstr16 rhs)const{ return !Equals(rhs); }
	eg_bool operator!=(eg_cpstr8 rhs)const{ return !Equals(rhs); }
	eg_bool operator!=(const eg_string& rhs)const{ return !Equals(rhs); }

	eg_char& operator[](const eg_size_t);

	operator eg_cpstr()const;
	operator const void*()const;
	operator const eg_string&()const;

	eg_cpstr String()const;
	eg_uint Length()const;

	//Conversion functions:
	eg_bool  IsNumber()const;
	eg_real  ToFloat()const;
	eg_uint  ToUInt()const;
	eg_uint  ToUIntArray(eg_uint* anOut, const eg_uint nMaxNums)const;
	eg_int   ToInt()const;
	eg_uint  ToUIntFromHex()const;
	eg_uint  ToRealArray(eg_real* Out, eg_uint MaxOut);

	void CopyTo(eg_char8* strOut, eg_size_t size_out)const;
	void CopyTo(eg_char16* strOut, eg_size_t size_out)const;

	static void Copy(eg_char* Dest, const eg_char8* Src, eg_uint size_out);
	static void Copy(eg_char* Dest, const eg_char16* Src, eg_uint size_out);
public:
	//Strings have a maximum size. This is so that strings never need to
	//allocate memory once they are created. This size can be changed as
	//necessary, but it should be as small as possible for optimization, and
	//so that the stack doesn't get filled up when strings are used.
	static const eg_uint STR_SIZE = 256;
	static const eg_char UNICODE_DOWNCAST_CHAR = ' ';
private:
	eg_char m_strString[STR_SIZE];
	eg_uint m_nLength;
private:
	void UpdateLength();
};

eg_string EGString_Format(eg_cpstr strFormat, ...);

static EG_INLINE eg_bool operator==(eg_cpstr16 lhs, const eg_string& rhs)
{
	return rhs == lhs;
}

static EG_INLINE eg_bool operator==(eg_cpstr8 lhs, const eg_string& rhs)
{
	return rhs == lhs;
}
static EG_INLINE eg_bool operator!=(eg_cpstr16 lhs, const eg_string& rhs)
{
	return rhs != lhs;
}

static EG_INLINE eg_bool operator!=(eg_cpstr8 lhs, const eg_string& rhs)
{
	return rhs != lhs;
}
